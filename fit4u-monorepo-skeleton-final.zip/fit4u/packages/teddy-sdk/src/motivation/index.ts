export * from "./teddyMotivation";
